﻿using System;
using System.Collections.Generic;
using System.IO;

namespace FileReader
{
    public delegate void FileReadCompletedDelegate(int count, string name);
    public class CSVReader
    {
        private string fileName;

        //public delegate void FileReadCompletedDelegate(int count, string name);
        //public event FileReadCompletedDelegate OnFileReadCompleted;

        public event EventHandler<ReadEventsArgs> OnFileReadCompleted;
        public CSVReader()
        {

        }
        public CSVReader(string fileName)
        {
            this.fileName = fileName;
        }
        public List<Car> ReadFile(string fileName)
        {
            int lineCount = 0;
            List<Car> cars = new List<Car>();
            using (StreamReader reader = new StreamReader(fileName))
            {
                string headerLine = reader.ReadLine();
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    string[] columns = line.Split(',');
                    Car car = new Car()
                    {
                        Year = int.Parse(columns[0]),
                        Manufacturer = columns[1],
                        Name = columns[2],
                        Displacement = double.Parse(columns[3]),
                        Cylinders = int.Parse(columns[4]),
                        City = int.Parse(columns[5]),
                        Highway = int.Parse(columns[6]),
                        Combined = int.Parse(columns[7])
                    };
                    cars.Add(car);
                    lineCount++;
                    if (car.Manufacturer == "BMW")
                    {
                        ReadEventsArgs args = new ReadEventsArgs(lineCount, line);
                        this.RaisFileReadCompletedEvent(this, args);
                        //OnFileReadCompleted(lineCount, line);
                        //this.OnFileReadCompleted(this, args);
                    }
                }
            }
            //if (this.OnFileReadCompleted != null)
            //{
            //    this.OnFileReadCompleted.Invoke(lineCount, line);
            //}
            return cars;
        }

        protected virtual void RaisFileReadCompletedEvent(object sender, ReadEventsArgs args)
        {
            if(this.OnFileReadCompleted !=null)
            {
                this.OnFileReadCompleted(sender, args);
            }

            // Or can be written as
            //this.OnFileReadCompleted?.Invoke(sender, args);
        }
    }
}
