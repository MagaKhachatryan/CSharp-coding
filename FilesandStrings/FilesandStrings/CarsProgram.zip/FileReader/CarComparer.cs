﻿using System.Collections.Generic;

namespace FileReader
{
    // We can also implement IComparer(not recommended) or IComparer<T> interfaces.
    public class CarComparer : Comparer<Car>
    {
        private static readonly CarComparer instance = new CarComparer();
        public static CarComparer Instance { get { return instance; } }

        private CarComparer()
        {
        }
        
        public override int Compare(Car x, Car y)
        {
            if (x.Year.Equals(y.Year))
                return string.Compare(x.Manufacturer, y.Manufacturer);

            return x.Year.CompareTo(y.Year);
        }
    }
}