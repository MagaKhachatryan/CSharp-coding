﻿using System;

namespace FileReader
{
    public class ReadEventsArgs : EventArgs
    {
        public int LineNumber { get; set; }
        public string CarInfo { get; set; }

        public ReadEventsArgs(int lineNumber, string carInfo)
        {
            this.LineNumber = lineNumber;
            this.CarInfo = carInfo;
        }
    }
}