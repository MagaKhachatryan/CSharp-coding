﻿using FileReader;
using System;
using System.Collections.Generic;
using static FileReader.CSVReader;

namespace CarsProgram
{
    class Program
    {
        private static string fileName = "cars.csv";
        static void Main(string[] args)
        {
            CSVReader reader = new CSVReader();
            //reader.OnFileReadCompleted += Reader_OnFileReadCompleted1;

            //reader.OnFileReadCompleted += new EventHandler<ReadEventsArgs>(Reader_OnFileReadCompleted);
            //reader.OnFileReadCompleted += (o, e) => { Console.WriteLine("{0}: {1}", e.LineNumber, e.CarInfo); };

            //reader.OnFileReadCompleted += Reader_OnFileReadCompleted;

            List<Car> cars = reader.ReadFile(fileName);

            // Car[] carsArray = cars.ToArray();
            //Array.Sort(carsArray, new CarComparer());  // carsArray will be sorted array; the order in List<Car> cars won't be changed.

            // In this case list of cars whill be sorted ofter Sort method 
            cars.Sort(CarComparer.Instance); 
            
            foreach (var item in cars)
            {
                //Console.WriteLine($"{item.Name}, {item.Year}, {item.Manufacturer}");
                //Console.WriteLine(item.Name + ", " + item.Year + "," + item.Manufacturer);
                Console.WriteLine(string.Format("Manufacturer: {0}, Year: {1}", item.Manufacturer, item.Year));
                
            }

            Console.ReadKey();
        }

        private static void Reader_OnFileReadCompleted(object sender, ReadEventsArgs e)
        {
            Console.WriteLine("{0}: {1}", e.LineNumber, e.CarInfo);
        }

        private static void Reader_OnFileReadCompleted(int lineCount, string info)
        {
            Console.WriteLine("{0}: {1}", lineCount, info);
        }
    }
}
