﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParallelForeachRotate
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] fileNames = Directory.GetFiles(@"\\Mac\Home\Desktop\Pugs");
            string newDir = @"\\Mac\Home\Desktop\Pugs\Modified";
            Directory.CreateDirectory(newDir);
            Parallel.ForEach(fileNames, (currentFile) => {
                //string filename = Path.GetFileName(fileName);
                string fileName = Path.GetFileName(currentFile);
                var image = new Bitmap(currentFile);
                image.RotateFlip(RotateFlipType.Rotate90FlipXY);
                image.Save(Path.Combine(newDir, fileName));
            });
            Console.ReadKey();
        }
    }
}
