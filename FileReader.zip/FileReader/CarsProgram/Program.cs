﻿using FileReader;
using System;

namespace CarsProgram
{
    class Program
    {
        private static string fileName = "cars.csv";
        static void Main(string[] args)
        {
            CSVReader reader = new CSVReader();
            reader.OnFileReadCompleted += Reader_OnFileReadCompleted;

            var cars = reader.ReadFile(fileName);

            //foreach (var item in cars)
            //{
            //    Console.WriteLine($"{item.Name}, {item.Year}, {item.Manufacturer}");
            //    Console.WriteLine(item.Name + ", " + item.Year + "," + item.Manufacturer);
            //    string.Format("Name: {0}, Year: {1}", item.Name, item.Year);
            //}

            Console.ReadKey();
        }

        private static void Reader_OnFileReadCompleted(object e, FileReadEventsArgs args)
        {
            Console.WriteLine("{0}: {1}", args.Line, args.Name);
        }

        //private static void Reader_OnFileReadCompleted(int lineCount, string info)
        //{
        //    Console.WriteLine("{0}: {1}", lineCount, info);
        //}
    }
}
