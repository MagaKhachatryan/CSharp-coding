﻿using System;
using System.Collections.Generic;
using System.IO;

namespace FileReader
{
    public class FileReadEventsArgs : EventArgs
    {
        public FileReadEventsArgs(int line, string name)
        {
            this.Line = line;
            this.Name = name;
        }
        public int Line { get; set; }
        public string Name { get; set; }
    }
    public class CSVReader
    {
        private string fileName;

        //public delegate void FileReadCompletedDelegate(int count, string name);
        //public event FileReadCompletedDelegate OnFileReadCompleted;

        public event EventHandler<FileReadEventsArgs> OnFileReadCompleted;

        public CSVReader()
        {

        }
        public CSVReader(string fileName)
        {
            this.fileName = fileName;
        }
        public List<Car> ReadFile(string fileName)
        {
            int lineCount = 0;
            List<Car> cars = new List<Car>();
            using (StreamReader reader = new StreamReader(fileName))
            {
                string headerLine = reader.ReadLine();
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    string[] columns = line.Split(',');
                    Car car = new Car()
                    {
                        Year = int.Parse(columns[0]),
                        Manufacturer = columns[1],
                        Name = columns[2],
                        Displacement = double.Parse(columns[3]),
                        Cylinders = int.Parse(columns[4]),
                        City = int.Parse(columns[5]),
                        Highway = int.Parse(columns[6]),
                        Combined = int.Parse(columns[7])
                    };
                    cars.Add(car);
                    lineCount++;
                    if (car.Manufacturer == "BMW" && this.OnFileReadCompleted != null)
                    {
                        this.OnFileReadCompleted(this, new FileReadEventsArgs(lineCount, line));
                    }
                }
            }
            //if (this.OnFileReadCompleted != null)
            //{
            //    this.OnFileReadCompleted.Invoke(lineCount, line);
            //}
            return cars;
        }
    }
}
