﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Ternary operator
            int myValue = -100;
            bool isValuePositive = false;

            //using if-else clause
            if (myValue  >= 0)
            {
                isValuePositive = true;
                Console.WriteLine("Number is positive.");
            }
            else
            {
                isValuePositive = false;
                Console.WriteLine("Number is negative.");
            }

            //using ternary operator
            bool isPositive = (myValue >= 0) ? true : false;
            #endregion

            #region Jumping statements - break, continue, goto, return, throw
            int[] ages = new int[] { 12, 20, 15, 45, 60, 57, 11, 51, 10 };

            //Print all ages except 45
            Console.WriteLine("-----------------------");
            foreach (var item in ages)
            {
                if (item == 45)
                    continue;
                Console.WriteLine(item);
            }

            // Print all ages untill the first one which has 11 as divisor
            Console.WriteLine("-----------------------");
            foreach (var item in ages)
            {
                if (item % 11 == 0)
                    break;
                Console.WriteLine(item);
            }

            #endregion

            #region processing input values
            //Instructions on console for users
            Console.WriteLine("Select which algorithm you want to perform:\n" +
                              "1. Bubble sort\n" +
                              "2. Insertion sort\n" +
                              "3. Quick sort\n" +
                              "4. Heap sort\n" +
                              "5. Merge sort\n" +
                              "6.All\n");

                                    

            // User's input for algorithms number
            string input = Console.ReadLine();
            List<string> algorithmNumbers = ProcessInput(input);
            foreach (var item in algorithmNumbers)
            {
                switch (item)
                {
                    case "1":                        
                        Console.WriteLine("Buuble Sort");
                        //BubbleSort();
                        break;
                    case "2":
                        Console.WriteLine("Insertion Sort");
                        //InsertionSort();
                        break;
                    case "3":
                        Console.WriteLine("Quick Sort");
                        //QuickSort();
                        break;
                    case "4":
                        Console.WriteLine("Heap Sort");
                        //HeapSort();
                        break;
                    case "5":
                        Console.WriteLine("Merge Sort");   
                        //MergeSort();
                        break;
                    case "6":                        
                        Console.WriteLine("All");
                        //BubbleSort();
                        //InsertionSort();
                        //MergeSort();
                        //QuickSort();
                        //HeapSort();
                        break;
                    default:
                        Console.WriteLine("Wrong imput");
                        break;
                }
            }

            #endregion

            #region processing input values using Enums
            Console.WriteLine("-----------------------");
            //Instructions on console for users
            Console.WriteLine("Select which algorithm you want to perform:\n" +
                              "1. Bubble sort\n" +
                              "2. Insertion sort\n" +
                              "3. Quick sort\n" +
                              "4. Heap sort\n" +
                              "5. Merge sort\n" +
                              "6.All\n");

            string otherInput = Console.ReadLine();
            List<Algorithms> algos = ProcessInputWithEnums(otherInput);
            foreach (var item in algos)
            {
                switch (item)
                {
                    case Algorithms.BubbleSort:
                        Console.WriteLine(item);
                        //BubbleSort();
                        break;
                    case Algorithms.InsertionSort:
                        Console.WriteLine(item);
                        //InsertionSort();
                        break;
                    case Algorithms.MergeSort:
                        Console.WriteLine(item);
                        //MergeSort();
                        break;
                    case Algorithms.QuickSort:
                        Console.WriteLine(item);
                        //QuickSort();
                        break;
                    case Algorithms.HeapSort:
                        Console.WriteLine(item);
                        //HeapSort();
                        break;
                    case Algorithms.All:
                        Console.WriteLine(item);
                        //BubbleSort();
                        //InsertionSort();
                        //MergeSort();
                        //QuickSort();
                        //HeapSort();
                        break;
                    default:
                        Console.WriteLine("Wrong imput");
                        break;
                }
            }
            #endregion

            Console.ReadKey();
        }

        private static List<string> ProcessInput(string input)
        {
            List<string> numbers = new List<string>();
            if (input.Contains('-'))
            {
                string[] ranges = input.Split('-');
                int start = Convert.ToInt32(ranges[0]);
                int end = Convert.ToInt32(ranges[1]);
                for (int number = start; number <= end; number++)
                {
                    numbers.Add(number.ToString());
                }
            }
            else if (input.Contains(','))
            {
                numbers = input.Split(',').ToList();
            }
            else
            {
                numbers.Add(input);
            }

            return numbers;
        }

        private static List<Algorithms> ProcessInputWithEnums(string input)
        {
            List<Algorithms> algos = new List<Algorithms>();

            if (input.Contains('-'))
            {
                string[] ranges = input.Split('-');
                int start = Convert.ToInt32(ranges[0]);
                int end = Convert.ToInt32(ranges[1]);
                for (int number = start; number <= end; number++)
                {

                    //algos.Add((Algorithms)Enum.Parse(typeof(Algorithms), number.ToString())); //Throws exception when conversion fails

                    Algorithms currAlgo;
                    Enum.TryParse(number.ToString(), out currAlgo); //returns bool which indicates whether the conversion succeeded
                    algos.Add(currAlgo);
                }
            }
            else if (input.Contains(','))
            {
                string[] ranges = input.Split(',');
                foreach (var item in ranges)
                {
                    algos.Add((Algorithms)Enum.Parse(typeof(Algorithms), item));
                }
            }
            else
            {
                algos.Add((Algorithms)Enum.Parse(typeof(Algorithms), input));
            }

            return algos;
        }
    }
}
