﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    enum Algorithms
    {
        BubbleSort = 1,
        InsertionSort = 2,
        MergeSort = 3,
        QuickSort = 4,
        HeapSort = 5,
        All = 6,
    }
}
