﻿using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;
using System;
using System.IO;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace AsyncProgramming
{
    class Program
    {
        static bool done = false;
        static string imageResourcesPath = @"C:\Users\adrine\Desktop\Pictures";

        static void Main(string[] args)
        {
            var url = "https://www.what-dog.net/Images/faces2/scroll0015.jpg";
            var fileName = Path.GetFileName(url);

            //Task<byte[]> downloadTask = DownloadImage(url); ;
            //var originalImageBytes = downloadTask.Result;
            //var originalImagePath = Path.Combine(imageResourcesPath, fileName);
            //Task saveTask = SaveImage(originalImageBytes, originalImagePath);

            //Task<byte[]> blurTask = BlurImage(originalImagePath);
            //var blurredImageBytes = blurTask.Result;
            //var blurredFileName = $"{Path.GetFileNameWithoutExtension(fileName)}_blurred.jpg";
            //var blurredImagePath = Path.Combine(imageResourcesPath, blurredFileName);

            //Task saveBlurTask = SaveImage(blurredImageBytes, blurredImagePath);

            // StartProcess(url);

            StartProcessAsync(url);

            while (!done)
            {
                Console.CursorLeft = 0;
                Console.Write(System.DateTime.Now.ToString("HH:mm:ss.fff"));
                Thread.Sleep(50);
            }

            Console.WriteLine("\nDone!");

            Console.WriteLine("\nHit Enter to exit the program...");
            Console.Read();
        }

        static void StartProcess(string url)
        {
            CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
            DownloadImage(url).ContinueWith(task1 =>
            {
                var fileName = Path.GetFileName(url);

                var originalImageBytes = task1.Result;
                var originalImagePath = Path.Combine(imageResourcesPath, fileName);
                SaveImage(originalImageBytes, originalImagePath).ContinueWith(task2 =>
                {

                    BlurImage(originalImagePath).ContinueWith(task3 =>
                    {
                        var blurredImageBytes = task3.Result;
                        var blurredFileName = $"{Path.GetFileNameWithoutExtension(fileName)}_blurred.jpg";
                        var blurredImagePath = Path.Combine(imageResourcesPath, blurredFileName);

                        //check
                        cancellationTokenSource.Cancel();


                        if (cancellationTokenSource.IsCancellationRequested)
                        {
                            //done = true;
                            Console.WriteLine("Canceled");
                        }
                        SaveImage(blurredImageBytes, blurredImagePath).ContinueWith(task4 =>
                        {
                            done = true;
                        });

                    });
                });
            });
        }
        static async Task StartProcessAsync(string url)
        {
            var fileName = Path.GetFileName(url);

            Console.WriteLine("Start downloading an image...");
            var originalImageBytes = await DownloadImage(url);
            var originalImagePath = Path.Combine(imageResourcesPath, fileName);
            Console.WriteLine("Finished download.");

            Console.WriteLine("\nSaving image...");
            await SaveImage(originalImageBytes, originalImagePath);
            Console.WriteLine("Finished saving.");

            Console.WriteLine("\nStart blurring downloaded image...");
            var blurredImageBytes = await BlurImage(originalImagePath);
            var blurredFileName = $"{Path.GetFileNameWithoutExtension(fileName)}_blurred.jpg";
            var blurredImagePath = Path.Combine(imageResourcesPath, blurredFileName);
            Console.WriteLine("Finished blurring.");

            Console.WriteLine("\nSaving blurred image...");
            await SaveImage(blurredImageBytes, blurredImagePath);
            Console.WriteLine("Finished saving blurred image.");

            done = true;
        }

        static Task<byte[]> DownloadImage(string url)
        {
            var client = new HttpClient();
            return client.GetByteArrayAsync(url);
        }

        static Task<byte[]> BlurImage(string imagePath)
        {
            return Task.Run(() =>
            {
                var image = Image.Load(imagePath);
                image.Mutate(ctx => ctx.GaussianBlur());
                using (var memoryStream = new MemoryStream())
                {
                    image.SaveAsJpeg(memoryStream);
                    return memoryStream.ToArray();
                }
            });
        }

        static Task SaveImage(byte[] bytes, string imagePath)
        {
            using (var fileStream = new FileStream(imagePath, FileMode.Create))
            {
                fileStream.Write(bytes, 0, bytes.Length);
            }
            return Task.FromResult<object>(null);
        }
    }
}
